package com.project.guest;

public enum Nonmember_Inquiry_Title {
	REGISTRATION,
	LIST,
	SEARCH

}
