package com.project.guest;

public class Guest_Menu {

	//테스트임 나중에 없애야함
	public void main() {
		
		Guest_Main guest = new Guest_Main();
		
		guest.gest();
		
	}
	
}