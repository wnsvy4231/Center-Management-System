package com.project.guest;

public class Test {
	public static void main(String[] args) {
		Guest_Main ge = new Guest_Main();
		ge.gest();
	}
	
	
}
