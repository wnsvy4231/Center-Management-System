package com.project.guest;

public enum Title {
	
	ADD,
	LIST,
	DELETE,
	SEARCH,
	CORRECT,
	SUBJECTLIST,
	SUBJECTSEARCH,
	TIMETABLE

}
