package com.project.admin;

public enum Admin_Consult_Title {
	LIST,
	ANSWER,
	SEARCH
	
}
