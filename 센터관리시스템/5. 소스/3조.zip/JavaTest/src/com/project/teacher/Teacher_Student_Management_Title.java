package com.project.teacher;

public enum Teacher_Student_Management_Title {
	ADD,
	CORRECT,
	DELETE,
	SEARCH,
	LIST

}
