package com.project.teacher;

public enum Data_Title {
	UPLOAD,
	CORRECT,
	DELETE,
	SEARCH,
	LIST

}
