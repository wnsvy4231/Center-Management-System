package com.project.student;

public class Timetable {
	
	private String timetable1;
	private String timetable2;
	private String timetable3;
	private String timetable4;
	private String timetable5;
	
	
	public String getTimetable1() {
		return timetable1;
	}
	public void setTimetable1(String timetable1) {
		this.timetable1 = timetable1;
	}
	public String getTimetable2() {
		return timetable2;
	}
	public void setTimetable2(String timetable2) {
		this.timetable2 = timetable2;
	}
	public String getTimetable3() {
		return timetable3;
	}
	public void setTimetable3(String timetable3) {
		this.timetable3 = timetable3;
	}
	public String getTimetable4() {
		return timetable4;
	}
	public void setTimetable4(String timetable4) {
		this.timetable4 = timetable4;
	}
	public String getTimetable5() {
		return timetable5;
	}
	public void setTimetable5(String timetable5) {
		this.timetable5 = timetable5;
	}	

}
