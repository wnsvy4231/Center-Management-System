package com.project.student;

public class Logintest {
	public static void main(String[] args) throws Exception {
		Login a = new Login();
		a.rogin();
	}
}
