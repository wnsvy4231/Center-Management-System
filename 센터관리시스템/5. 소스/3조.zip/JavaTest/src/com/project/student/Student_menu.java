package com.project.student;

public class Student_menu {

	//main은 테스트용임. 나중에 삭제해야됨
	public void main() {
		
		StudentMain std = new StudentMain();
		
		std.studentMain();
		
	}
	
}