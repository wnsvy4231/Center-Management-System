package com.project.student;

public class Test {
	
	public static void main(String[] args) {
		
		StudentMain main = new StudentMain();
		main.studentMain();
		
	}	

}
