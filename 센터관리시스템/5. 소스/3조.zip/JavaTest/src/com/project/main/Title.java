package com.project.main;

public enum Title {
	
	ADD,
	LIST,
	DELETE,
	SEARCH,
	CORRECT,
	SUBJECTLIST,
	SUBJECTSEARCH,
	TIMETABLE

}
