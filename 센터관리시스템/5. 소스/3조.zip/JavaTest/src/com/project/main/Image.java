package com.project.main;

public class Image {
	public void a1() {
	System.out.println("\r\n" + 
			"████████╗██╗  ██╗ █████╗ ███╗   ██╗██╗  ██╗    ██╗   ██╗ ██████╗ ██╗   ██╗\r\n" + 
			"╚══██╔══╝██║  ██║██╔══██╗████╗  ██║██║ ██╔╝    ╚██╗ ██╔╝██╔═══██╗██║   ██║\r\n" + 
			"   ██║   ███████║███████║██╔██╗ ██║█████╔╝      ╚████╔╝ ██║   ██║██║   ██║\r\n" + 
			"   ██║   ██╔══██║██╔══██║██║╚██╗██║██╔═██╗       ╚██╔╝  ██║   ██║██║   ██║\r\n" + 
			"   ██║   ██║  ██║██║  ██║██║ ╚████║██║  ██╗       ██║   ╚██████╔╝╚██████╔╝\r\n" + 
			"   ╚═╝   ╚═╝  ╚═╝╚═╝  ╚═╝╚═╝  ╚═══╝╚═╝  ╚═╝       ╚═╝    ╚═════╝  ╚═════╝ \r\n" + 
			"                                                                          \r\n" + 
			""); 
 }
	public void a2() {
		System.out.println("\r\n" + 
				"███████╗███████╗ █████╗ ███╗   ██╗ ██████╗██╗   ██╗ ██████╗ ███╗   ██╗ ██████╗ \r\n" + 
				"██╔════╝██╔════╝██╔══██╗████╗  ██║██╔════╝╚██╗ ██╔╝██╔═══██╗████╗  ██║██╔════╝ \r\n" + 
				"███████╗███████╗███████║██╔██╗ ██║██║  ███╗╚████╔╝ ██║   ██║██╔██╗ ██║██║  ███╗\r\n" + 
				"╚════██║╚════██║██╔══██║██║╚██╗██║██║   ██║ ╚██╔╝  ██║   ██║██║╚██╗██║██║   ██║\r\n" + 
				"███████║███████║██║  ██║██║ ╚████║╚██████╔╝  ██║   ╚██████╔╝██║ ╚████║╚██████╔╝\r\n" + 
				"╚══════╝╚══════╝╚═╝  ╚═╝╚═╝  ╚═══╝ ╚═════╝   ╚═╝    ╚═════╝ ╚═╝  ╚═══╝ ╚═════╝ \r\n" + 
				"                                                                               \r\n" + 
				"");
	}
	
	public void a3() {
		System.out.println("                                    ,,,wwWWWWWwww        w        ,Wjy5555555yjw      ,             \r\n" + 
				"                              wj555555DBBBBBDDyyy555yyWzD,  ,9ZEZEEZZZZZZZZZ989EZZZD8ZZZy           \r\n" + 
				"                           ,jBD5yWj5BDD     ,jDB5jWj5By   EZZE8BB9ZZ95,   WDZZZBDBEZZZ              \r\n" + 
				"                         ,zB5jWWjDBD            5DDDj  ,8ZEzDDB9ZEy           jZZZZ,                \r\n" + 
				"                       WDByWWWjyD,               ,W   ZZEDDDB9EZ                Z9                  \r\n" + 
				"                     ,WDjWWWWj5yw                   z8EDDDDD99j                                     \r\n" + 
				"                    w5DjWWjWW5jw                   ZE8DDDDDzZ                                       \r\n" + 
				"                    ByjWWWWjjD                   y9ZBDBBBD88Z                                       \r\n" + 
				"                  w5yjWWWWjjjy                  58EDDDDBD5ZD                                        \r\n" + 
				"                 jjDWjjWWWWjjW                  Z8zDBBBBBDED                                        \r\n" + 
				"                 8yjWWjWWWWjjj                w,ZBDBDDDDBDED                                        \r\n" + 
				"                 8jWWWWWWWWjj5                B99DDBDDDBBDEBw                                       \r\n" + 
				"               , BjWWWWWWWWWjD,               zZDDDBBDDBBDz8Z                                       \r\n" + 
				"               ,,DjWWWWWWWjWjyDj              8ZyBBDDDDBBBDzZW                                      \r\n" + 
				"               ,wDjWWWWWWWjWWWy55             8Z5DDBDDDBBBBDzZB5                                    \r\n" + 
				"               , BjWjjWWWWjjjWWj5By           zZBDDBDDDBDBBBDBEZB,                                  \r\n" + 
				"                 8jjWWjWWWjjjWWWWj5z,         5BZBDDDDBDDDDBDDDBZZZ                                 \r\n" + 
				"                 yj5WWjWWWWWWWWWWWWjDDD         Z8BDDBBBDBDDDDBBDzZZ9w                              \r\n" + 
				"                  w55jWWWWWWWWWWWWjWWjDyjW      59ZBDBDDBBDDDBBBDDDz9ZEj                            \r\n" + 
				"                    DyyWWWWWWWWWWWWWWWjjyD5W     WBZzDDBBBDBDDDBBBDDDz9ZZD                          \r\n" + 
				"                     58DyjjWjWWWWWWWWWjWWjy55,     EZZzDDDBDDDDDDDDDBBDB8ZZB                        \r\n" + 
				"                       W5DyjjWjjjWWWWjjWWjjjy85y      ZZ9BBBBBBBBBDDDDBDDDzZZj                5     \r\n" + 
				"                         WDD5jWWWWWWWWjjjWWWWWyDw      DEZEzBDDBDDBDDDBBBBDD8ZZ           w9ZZZ     \r\n" + 
				"                           wjD5yjWWWWWWjWWWWjjjjBw       w9EZ9BDDBBDDDBBBBDDD8EZ         ZZZZB      \r\n" + 
				"                              W5z5jWWWWWWWWjWWWWyyy          ZZZBDBDDDDDDDDBDDBZW,       ZZZZ       \r\n" + 
				"                                 555WWWjWWWWWjWjWy5            jZ8BDDBBDDDBBBDDEz5 ZZZZZzZZZZZ9ZZZy,\r\n" + 
				"                                  wB5jWWWWWWWWWjWyyw      ZZZ   EEZBDBDDDDBBDDDz9D ZZZZZZZZZZZZZZZ  \r\n" + 
				"                                    B5jWjWWWWWjWWjyW      ZZZ     5ZBDDDDDBBBBDBEz      ZZZZ        \r\n" + 
				"                                    wW5WWWWWWWWWWyyW               ZzBDBDBDDDDDBZz     DZZ9Z        \r\n" + 
				"                                     w5jWWWWWWWWWyy,   w9ZZZ       ED9DDDBBBDDD89D    ZZZZzW        \r\n" + 
				"                                     WDyjWWWWWjjWy5  ,ZZZZZZ       jyZ5DDBBBBDDZDj    ZZZZD         \r\n" + 
				"                                       DD5jWWWWWyyy   5  ZEz       wyZ5DDBBBDDBZW,    ZZZE5         \r\n" + 
				"    wjjW                          wBBj,   DyjjWWBW     wzZ ,       B5E5DDDBBDB8Z     ZZZZ           \r\n" + 
				"  DBBD5D8DW                     9ZZZZZZZ,  j5Wj55      ZZZ         ZBzDBDBBDDZZ     wZZZZ           \r\n" + 
				" 55yWWWWWyzW                   jZDDDDDD9ZZ   D5D      DZZ          ZzBDBBDDzZB5    8zZZ8Z           \r\n" + 
				" 5yjWWWWWWj5jj                 jZ5DBBBDDBZ9W y,,      ZZy        wzEBDDBDB9Z9      ZZZZ85           \r\n" + 
				" W5yWWjWWWWjyz                 WZzDDBDDBDDE9B       , Zj5ZZ8    8zZBDBDDBZEz       ZZZZ5            \r\n" + 
				"  5DDjWWWWWjjy5yj               wZZzDDDDBDDzEZ      ZZZZZZ     jZ8BDDDBZZ8,       wZZZZy   5yw      \r\n" + 
				"    5BDyjWWWWWjyDDj           W,  WZZ9BDDDDDB9ZZ8     B      ZZEzDDB9ZZ5          ZZZZ   ZZZZZ      \r\n" + 
				"      wBBD5yyjjWWy5BB5yjjjjy5BDDB   DZZZE9zzBBDBZZZZBw  y8ZZZ9BB8EZZEy           5ZZZZjZZZZZ        \r\n" + 
				"         ,j555D5y5yy55DDDDDDD555Dzz5   Bz9ZZZZZE999ZZZZZZZZEEEZZE8B             8ZZZZZZZZW          \r\n" + 
				"                 ,,,www,w,,,,                  ,wWjjjjjjWWw,,                    ,zBD5              \r\n" + 
				"");
	}
	
	public void a4() {
		System.out.println("░░░░░░░░░░░░▄▄▄█▀▀▀▀▀▀▀▀█▄▄▄░░░░░░░░░░░░\r\n" + 
				"░░░░░░░░▄▄█▀▀░░░░░░░░░░░░░░▀▀█▄▄░░░░░░░░\r\n" + 
				"░░░░░░▄█▀░░░░▄▄▄▄▄▄▄░░░░░░░░░░░▀█▄░░░░░░\r\n" + 
				"░░░░▄█▀░░░▄██▄▄▄▄▄▄▄██▄░░░░▄█▀▀▀▀██▄░░░░\r\n" + 
				"░░░█▀░░░░█▀▀▀░░▄██░░▄▄█░░░██▀▀▀███▄██░░░\r\n" + 
				"░░█░░░░░░▀█▀▀▀▀▀▀▀▀▀██▀░░░▀█▀▀▀▀███▄▄█░░\r\n" + 
				"░█░░░░░░░░░▀▀█▄▄██▀▀░░░░░░░░▀▄▄▄░░░▄▄▀█░\r\n" + 
				"█▀░░░░░░░░░░░░░░░░░░░░░░░░░░░░░▀▀▀▀▀░░▀█\r\n" + 
				"█░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░▄░░░░█\r\n" + 
				"█░░░░░░░░░░░░░░░░░░░░░░░░▄▄▄▄▄██░░▀█░░░█\r\n" + 
				"█░░░░░░░░░░░░░░█░░░▄▄▄█▀▀▀░░░▄█▀░░░░░░░█\r\n" + 
				"█░░░░░░░░░░░░░░░░░░▀░░░░░░░░█▀░░░░░░░░░█\r\n" + 
				"█▄░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░▄█\r\n" + 
				"░█░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░█░\r\n" + 
				"░░█░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░█░░\r\n" + 
				"░░░█▄░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░▄█░░░\r\n" + 
				"░░░░▀█▄░░░░░░░░░░░░░░░░░░░░░░░░░░▄█▀░░░░\r\n" + 
				"░░░░░░▀█▄░░░░░░░░░░░░░░░░░░░░░░▄█▀░░░░░░\r\n" + 
				"");
	}
	public void a5() {
		System.out.println(" BEzBBD5yEw  ZZ9                 ZZZ          ZE      ZZj                 jZZ                 ZZD   \r\n" + 
				" ZZZZZZZZZw  ZZ9         ZZ8     ZZZ    WZZZZZZZZZZZZ ZZ,     ZZZ         WZZ     ZZZZZZZZZZ  ZZD   \r\n" + 
				"       ZZW   ZZD         ZZw     ZZZ                  ZZ      ZZZ         WZZ     DZZ         ZZD   \r\n" + 
				"     ZZZy    ZZZZZZ      ZZW     ZZZ       ZZZZZZZE   ZZZZZj  ZZZ         WZZ     DZZ         ZZ    \r\n" + 
				" ,ZZZZZ      ZZB         ZZZ     ZZZZZZ  wZZ     ZZZ  ZZ, ,   ZZZ         WZZ     DZZ         ZZZZZ8\r\n" + 
				"wZZZy        ZZZ        ZZZZ8    ZZZZZZ   ZZZZZZZZZZ  ZZw     ZZZ         WZZ     DZZ         ZZZZZZ\r\n" + 
				"                      yZZD ZZZ   ZZZ        yZZZZj    ZZ,     ZZZ         ,ZZ     DZZ         ZZ    \r\n" + 
				"   zZZZZZZZZZZZZ    ZZZZ    ZZZZ ZZZ        zB        z8      ZZZZZZZZZZZ ,ZZ     ZZZZZZZZZZZ ZZD   \r\n" + 
				"   wZZ       EZZ    wZZ       ZD ZZZ        ZZZZZZZZZZZZy                 ,ZZ               , ZZD   \r\n" + 
				"   wZZ       9ZZ                 ZZZ        ZZ        ZZW                 wZZ                 ZZD   \r\n" + 
				"   WZZZZZZZZZZZ9                 ZZZ        ZZZZZZZZZZZZj                 jZZ                 ZZD   \r\n" + 
				"");
	}
	public void a6() {
		System.out.println("  wB   Z   5Z       WZZZZZZZZw       jw,,,,,,          5ZZZZZZZZ         Zy    Z5 Z8       ,,,wy   Z\r\n" + 
				"  ZZ   Z   5Z       Z        Z,     WZZZZZZZZZZZ      yZ       ,Z        ZE    Zy ZE    ZZ9ZZZZZ,  Z\r\n" + 
				" jZEZ ZZZ  WZZZZ    ZZEy5Dy8ZZ                5Z       ZZZ5DD8ZZZ        ZZ ZZZZy ZE    9Z         Z\r\n" + 
				"BZ  8ZZ ZZywZ         Z5BByZz                 9Z          BBBD          ZZZZ   Zy ZE    9ZDZZZ9    Z\r\n" + 
				"w   E      wZ    ZZZZZZEZZ9ZZZZZZ     5Z   Z  9Z   wZZZZZZZZZZZZZZZZ  ZZZ  EZZ ZD ZE    9Z BB8yyZZZZ\r\n" + 
				"    8ZZZZZZW           D88B            Z   Z  ZZ        yZ    Z       z        ZE ZZ    9Z         Z\r\n" + 
				"   ZZ      ZZ       ZZZ9zz9ZZZ         Z   Z          ZZZZZZZZZZZ        ZZ    8  ZZ    ZZZZZZZZZ, Z\r\n" + 
				"  zZ        Z       Z        Z    ZZZZZZZZZZZZZZZZB             Z        Zy                     w  Z\r\n" + 
				"   yZZZZZZZZ,       5ZZZZZZZZD                                  Z        ZZZZZZZZZZZ               Z\r\n" + 
				"");
		
	}
}
