package com.project.main;

import com.project.student.Login;

public class Center_Management_System {

	public static void main(String[] args) throws Exception {
		
		Login login = new Login();
		
		boolean loop = true;
		
		while (loop) {
			login.rogin();
		}//while
		
	}//main
	
}//Center_Management_System